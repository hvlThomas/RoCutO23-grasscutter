# HuskySimulation
Simulation tools fot the Husky Robot, used with the HVL Husky

To start the simulation world:
```
roslaunch husky_simulation tunnel_world.launch
```

To spawn the robot:
```
roslaunch husky_simulation spawn_husky.launch
```

